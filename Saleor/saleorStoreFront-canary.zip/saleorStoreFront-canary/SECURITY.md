# Reporting a Vulnerability

If you discover a security vulnerability in storefront please disclose it via [our huntr page](https://huntr.dev/repos/saleor/storefront/). Information about bounties, CVEs, response times and past reports are all there.

Thank you for improving the security of storefront.
